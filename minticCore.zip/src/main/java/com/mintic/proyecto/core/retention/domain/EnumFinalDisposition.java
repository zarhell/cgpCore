package com.mintic.proyecto.core.retention.domain;

public enum EnumFinalDisposition {

   TOTAL_CONSERVATION,
   ELIMINATION,
   MICROFILMING,
   SELECTION;

}
