package com.mintic.proyecto.core.search.domain;


public enum EnumDocumentPriority {

    HIGHT, MEDIUM, LOWl;
}
