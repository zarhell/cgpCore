package com.mintic.proyecto.core.commons.constans;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final  class ConstansCore {

    public static final String BUCKET_NAME = "mintinc-tripulantes10";
    
}
