package com.mintic.proyecto.core.upload.config;

import org.springframework.stereotype.Service;

@Service
public class GcpCredentials {
    
}
