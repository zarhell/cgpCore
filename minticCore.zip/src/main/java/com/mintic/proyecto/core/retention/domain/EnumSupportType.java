package com.mintic.proyecto.core.retention.domain;

public enum EnumSupportType {
  
    PAPER, 
    ELECTRONIC;  
}
