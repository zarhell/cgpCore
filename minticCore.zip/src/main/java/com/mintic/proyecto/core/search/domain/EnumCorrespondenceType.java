package com.mintic.proyecto.core.search.domain;


public enum EnumCorrespondenceType {

    INTERN, EXTERN;


}
